import enum
from card_deck import Card, Deck, Color, Value
from combinaison import Combinaison

string = "P"

print(Combinaison.COULEUR, Color.P)
